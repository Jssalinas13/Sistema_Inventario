<?php
use PHPUnit\Framework\TestCase;
require_once __DIR__ . '/../proyecto/conexion/conectar.php';

class conectarTest extends TestCase {
    public function testConectandoReturnsConnection() {
        $conectar = new conexion();
        $con = $conectar->conectando();
        $this->assertInstanceOf(mysqli::class, $con);
        $this->assertNotFalse($con);   
        $con->close();
    
    }

}